#!/bin/bash

# Get the number from command line argument
num=$1

# Store the original number
originalNum=$num

# Initialize sum
sum=0

# Get the number of digits in the number
numOfDigits=${#num}

# Check if the number is an Armstrong number
while [ $num -gt 0 ]
do
  # Get the last digit of the number
  digit=$((num % 10))

  # Raise the digit to the power of the number of digits
  digit=$((digit ** numOfDigits))

  # Add the digit to the sum
  sum=$((sum + digit))

  # Remove the last digit from the number
  num=$((num / 10))
done

# Check if the sum is equal to the original number
if [ $sum -eq $originalNum ]
then
  echo "$originalNum is an Armstrong number"
else
  echo "$originalNum is not an Armstrong number"
fi

